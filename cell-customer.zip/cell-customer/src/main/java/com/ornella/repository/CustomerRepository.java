package com.ornella.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ornella.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

}
