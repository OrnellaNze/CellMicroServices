package com.ornella;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CellCustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CellCustomerApplication.class, args);
	}

}
