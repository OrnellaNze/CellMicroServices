package com.ornella.service;


import java.util.Optional;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ornella.dto.CustomerDTO;
import com.ornella.dto.LoginDTO;
import com.ornella.entity.Customer;
import com.ornella.repository.CustomerRepository;

@Service
public class CustomerService {
	Log logger = LogFactory.getLog(this.getClass());
	@Autowired
	CustomerRepository custRepo;
	
	public void createCustomer(CustomerDTO custDTO) {
		logger.info("Creation request for customer "+ custDTO);
		Customer cust = custDTO.createEntity();
		custRepo.save(cust);
	}

//Login
	public boolean login(LoginDTO loginDTO) {
		logger.info("Login request for customer "+loginDTO.getPhoneNo() +" with password "+loginDTO.getPassword());
		Optional<Customer> optCust = custRepo.findById(loginDTO.getPhoneNo());
		if (optCust.isPresent()) {
			Customer cust = optCust.get();
			if (cust.getPassword().equals(loginDTO.getPassword())) {
				return true;
			}
		}
		return false;
		
	}
	
	//Fetches full profile of a specific customer
	public CustomerDTO getCustomerProfile(Long phoneNo) {
		CustomerDTO custDTO = null;
		logger.info("Profile request for customer "+ phoneNo);
		Optional<Customer> optCust = custRepo.findById(phoneNo);
		if (optCust.isPresent()) {
			Customer cust = optCust.get();
			custDTO = CustomerDTO.valueOf(cust);
		}
		logger.info("Profile for customer : "+custDTO);
		
		return custDTO;
		
	}
}
