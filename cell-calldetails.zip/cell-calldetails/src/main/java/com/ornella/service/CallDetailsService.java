package com.ornella.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.ornella.dto.CallDetailsDTO;
import com.ornella.entity.CallDetails;
import com.ornella.repository.CallDetailsRepository;

@Service
public class CallDetailsService {
Log logger = LogFactory.getLog(CallDetails.class);
@Autowired
CallDetailsRepository callDetailsRepo;

//Fetches call details of a specific customer
public List<CallDetailsDTO> getCustomerDetails(@PathVariable long phoneNo){
	logger.info("CallDetails request for customer"+ phoneNo);
	List<CallDetails> callDetails = callDetailsRepo.findByCalledBy(phoneNo);
	List<CallDetailsDTO> callsDTO = new ArrayList<>();
	
	for (CallDetails call : callDetails) {
		callsDTO.add(CallDetailsDTO.valueOf(call));
	}
	logger.info("CallDetails for customer : "+ callDetails);
	return callsDTO;
}
}
