package com.ornella;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CellCalldetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CellCalldetailsApplication.class, args);
	}

}
