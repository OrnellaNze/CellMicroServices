package com.ornella;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CellCalldetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
