package com.ornella.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Plan {

	@Id
	@Column(name = "plan_id", nullable = false)
	Integer PlanId;
	@Column(name = "plan_name", nullable = false, length = 50)
	String PlanName;
	@Column(name = "national_rate", nullable = false)
	Integer natioanalRate;
	@Column(name = "local_rate", nullable = false)
	Integer localRate;
	public Integer getPlanId() {
		return PlanId;
	}
	public void setPlanId(Integer planId) {
		PlanId = planId;
	}
	public String getPlanName() {
		return PlanName;
	}
	public void setPlanName(String planName) {
		PlanName = planName;
	}
	public Integer getNatioanalRate() {
		return natioanalRate;
	}
	public void setNatioanalRate(Integer natioanalRate) {
		this.natioanalRate = natioanalRate;
	}
	public Integer getLocalRate() {
		return localRate;
	}
	public void setLocalRate(Integer localRate) {
		this.localRate = localRate;
	}
	public Plan() {
		super();
	}
	
	
}
